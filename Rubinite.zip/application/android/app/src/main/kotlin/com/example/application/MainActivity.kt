package com.example.application

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
